<?php

$conn = mysqli_connect('localhost:3306','ittleps7_foxrock619','godlove@4772','ittleps7_comments');

if(!$conn){
	die("Connection failed: ".mysqli_connect_error());
}