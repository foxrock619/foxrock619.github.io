<?php

function setComments(){
	if(isset($_POST['commentSubmit']){
		
	}
	
}
>